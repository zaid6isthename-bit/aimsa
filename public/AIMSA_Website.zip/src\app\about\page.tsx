import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { EditorialHeader } from '@/components/ui/EditorialHeader';
import { EditorialFooter } from '@/components/ui/EditorialFooter';
import { ArrowRight, BookOpen, Compass, Target, Heart, History, Award } from 'lucide-react';
import { StampBadge } from '@/components/ui/StampBadge';

export default function AboutPage() {
  const timelineEvents = [
    {
      year: '2024 (INCEPTION)',
      title: 'Founding of AIMSA Council',
      desc: 'Formed by 4th-year AI & ML undergraduates with a vision to unite technical excellence and human student culture.',
    },
    {
      year: 'FALL 2024',
      title: 'First Neural Hackathon & AURA Fest',
      desc: 'Hosted 250+ hackathon participants and 600+ cultural fest attendees, establishing AIMSA as the largest dept council.',
    },
    {
      year: 'SPRING 2025',
      title: 'National Wall of Fame & Inter-Dept Trophy',
      desc: 'Won 1st place in 3 national AI hackathons and secured the University All-Sports Championship Trophy.',
    },
    {
      year: 'PRESENT (2025-26)',
      title: 'Expanding the Digital Archive',
      desc: 'Operating 15+ annual workshops, mentorship circles, research reading groups, and global alumni networks.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#E6E1D7] text-[#121110] paper-crumpled-bg flex flex-col font-sans">
      <EditorialHeader />

      <main className="flex-1 pt-28 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full select-none">
        {/* Page Hero Header */}
        <div className="border-b border-black/15 pb-12 mb-16">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <span className="font-mono-tech text-xs uppercase tracking-widest text-[#D92525] font-bold">
                OFFICIAL FIELD-JOURNAL ARCHIVE
              </span>
              <h1 className="font-syne font-black text-5xl sm:text-7xl text-[#121110] uppercase tracking-tight mt-2">
                ABOUT <span className="red-marker-line">AIMSA</span>
              </h1>
            </div>
            <StampBadge size={110} variant="red" text="• EST. 2024 • AI & ML DEPT COUNCIL •" />
          </div>

          <p className="font-mono-tech text-sm sm:text-base text-neutral-700 max-w-2xl mt-6 leading-relaxed">
            AIMSA (AI & ML Students' Association) is the living, breathing student body of the Department of Artificial Intelligence & Machine Learning. We bridge technical mastery with creative culture, sports grit, and lifelong campus friendships.
          </p>
        </div>

        {/* Identity & Story Scrapbook Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-24">
          <div className="lg:col-span-6 space-y-6 bg-[#F9F7F1] border border-black/15 p-8 rounded-xs shadow-xl tape-effect tape-kraft">
            <h2 className="font-syne font-black text-3xl text-[#121110] uppercase">
              WHO WE ARE & OUR ORIGIN
            </h2>
            <p className="font-mono-tech text-xs text-neutral-800 leading-relaxed">
              Founded in 2024 by ambitious AI undergraduates, AIMSA was born out of a realization: engineering education is incomplete without a thriving, supportive community. We refuse to be just another academic portal or silent laboratory.
            </p>
            <p className="font-mono-tech text-xs text-neutral-800 leading-relaxed">
              Instead, AIMSA operates as a student-run digital archive and event platform. From 36-hour hackathons and PyTorch research workshops to acoustic rock nights, sports tournaments, and pizza lawn jams—AIMSA is where memories are forged.
            </p>

            <div className="pt-4 border-t border-black/10 font-handwriting text-xl text-neutral-800 flex justify-between">
              <span>"Not just code—culture, grit and community."</span>
              <span className="text-xs font-mono-tech text-neutral-500">AIMSA DEPT COUNCIL</span>
            </div>
          </div>

          <div className="lg:col-span-6 relative flex justify-center">
            <div className="relative w-full max-w-md polaroid-card-light p-4 bg-white border border-black/15 shadow-2xl transform rotate-2">
              <div className="relative w-full aspect-[4/3] bg-neutral-900 overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000"
                  alt="AIMSA Council Members"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="mt-3 text-center font-handwriting text-xl text-neutral-800">
                AIMSA Founders & Council Meeting • Lab 3
              </div>
            </div>
          </div>
        </div>

        {/* Vision, Mission, Values Grid */}
        <div className="mb-24">
          <div className="text-center mb-12">
            <h2 className="font-syne font-black text-4xl text-[#121110] uppercase">
              VISION, MISSION & VALUES
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#FAF8F5] border border-black/15 p-8 rounded-xs shadow-lg space-y-4">
              <div className="w-12 h-12 bg-[#D92525]/10 text-[#D92525] rounded-full flex items-center justify-center font-bold">
                <Compass className="w-6 h-6" />
              </div>
              <h3 className="font-syne font-bold text-2xl uppercase text-[#121110]">OUR VISION</h3>
              <p className="font-mono-tech text-xs text-neutral-700 leading-relaxed">
                To build the most vibrant, technically fearless, and supportive AI & ML student community in the nation—where every member finds their voice, team, and passion.
              </p>
            </div>

            <div className="bg-[#FAF8F5] border border-black/15 p-8 rounded-xs shadow-lg space-y-4">
              <div className="w-12 h-12 bg-[#D92525]/10 text-[#D92525] rounded-full flex items-center justify-center font-bold">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="font-syne font-bold text-2xl uppercase text-[#121110]">OUR MISSION</h3>
              <p className="font-mono-tech text-xs text-neutral-700 leading-relaxed">
                Empower students through high-impact hackathons, PyTorch bootcamps, inter-department sports leagues, cultural showcases, and direct peer mentorship.
              </p>
            </div>

            <div className="bg-[#FAF8F5] border border-black/15 p-8 rounded-xs shadow-lg space-y-4">
              <div className="w-12 h-12 bg-[#D92525]/10 text-[#D92525] rounded-full flex items-center justify-center font-bold">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="font-syne font-bold text-2xl uppercase text-[#121110]">OUR VALUES</h3>
              <p className="font-mono-tech text-xs text-neutral-700 leading-relaxed">
                Uncompromising student brotherhood, open-source knowledge sharing, athletic sportsmanship, creative freedom, and relentless pursuit of excellence.
              </p>
            </div>
          </div>
        </div>

        {/* Timeline Section */}
        <div className="mb-20 bg-[#F9F7F1] border border-black/15 p-8 sm:p-12 rounded-xs shadow-xl">
          <div className="mb-8">
            <h2 className="font-syne font-black text-3xl text-[#121110] uppercase flex items-center gap-3">
              <History className="w-7 h-7 text-[#D92525]" />
              <span>TIMELINE & MILESTONES</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 font-mono-tech">
            {timelineEvents.map((t, idx) => (
              <div key={idx} className="border-l-2 border-[#D92525] pl-4 py-2 space-y-2">
                <span className="text-xs font-bold text-[#D92525] uppercase tracking-widest">
                  {t.year}
                </span>
                <h4 className="font-bold text-sm text-[#121110] uppercase">{t.title}</h4>
                <p className="text-xs text-neutral-600 leading-relaxed">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation CTAs */}
        <div className="flex flex-wrap items-center justify-between gap-6 pt-8 border-t border-black/15">
          <Link
            href="/people"
            className="px-8 py-3.5 rounded-full bg-[#121110] hover:bg-[#D92525] text-white font-mono-tech font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center gap-2"
          >
            <span>MEET THE PEOPLE OF AIMSA</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/events"
            className="px-8 py-3.5 rounded-full border border-black/80 hover:bg-black/10 text-[#121110] font-mono-tech font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2"
          >
            <span>EXPLORE OUR EVENT ECOSYSTEM</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </main>

      <EditorialFooter />
    </div>
  );
}
